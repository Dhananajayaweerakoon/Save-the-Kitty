package com.example.savethekitty

interface Gametask {
    fun closeGame(mScore:Int)
}