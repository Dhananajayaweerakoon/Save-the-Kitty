package com.example.savethekitty

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity(),Gametask{
    lateinit var rootLayout :LinearLayout
    lateinit var startbtn :Button
    lateinit var mGameview: Gameview
    lateinit var score:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startbtn = findViewById(R.id.startBtn)
        rootLayout = findViewById(R.id.rootLayout)
        score = findViewById(R.id.score)
        mGameview = Gameview(this,this)
        startbtn.setOnClickListener {
            mGameview.setBackgroundResource(R.drawable.back)
            rootLayout.addView(mGameview)
            startbtn.visibility = View.GONE
            score.visibility = View.GONE
        }
    }

    override fun closeGame(mScore: Int) {
        score.text = "Score : $mScore"
        rootLayout.removeView(mGameview)
        startbtn.visibility = View.VISIBLE
        score.visibility = View.VISIBLE
    }
}